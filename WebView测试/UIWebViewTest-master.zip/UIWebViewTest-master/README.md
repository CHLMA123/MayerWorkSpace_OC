# UIWebViewTest
WebView基本使用，打开本地文件，打开网站，导航栏与js交互等等，[点击这里参见博客详细介绍](http://www.cnblogs.com/mddblog/p/5281748.html) 界面如下图：

<div align="center">   
<img src="http://7xs4tc.com1.z0.glb.clouddn.com/mddBlog3.0.png" alt="加载失败" width="300px">
</div>

