//
//  AppDelegate.h
//  WebViewTest
//
//  Created by mdd on 16/3/9.
//  Copyright © 2016年 com.personal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

