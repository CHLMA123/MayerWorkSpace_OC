# WKWebViewTest
WKWebView使用，可以加载本地文件和网络内容。实现简单的搜索界面，如下图，[点击这里参见博客更详细介绍](http://www.cnblogs.com/mddblog/p/5281748.html)

<div align="center">   
<img src="http://7xs4tc.com1.z0.glb.clouddn.com/mddBlog3.0.png" alt="加载失败" width="300px">
</div>

