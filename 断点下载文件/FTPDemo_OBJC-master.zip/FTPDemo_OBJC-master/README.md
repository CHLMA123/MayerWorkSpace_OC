FTPDemo_OBJC
============
This is a FTP Demo ,which can upload and download files.
In addition ,it can scatter big file to pieces for the reason that it can upload a big file with stop and resume options.
When you stop uploading ,the program itself will record the number of pieces you've uploaded.
Then ,you can upload the piece from the stop one by clicking the resume button.
