//
//  main.m
//  FTPDemo_OBJC
//
//  Created by Turtleeeeeeeeee on 14/11/12.
//  Copyright (c) 2014年 SCNU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
