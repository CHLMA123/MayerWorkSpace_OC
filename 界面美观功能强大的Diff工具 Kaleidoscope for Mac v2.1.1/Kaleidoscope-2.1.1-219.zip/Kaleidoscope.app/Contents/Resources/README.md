
Before you start messing, go to the wiki: 

<old wiki Build-Configurations>
