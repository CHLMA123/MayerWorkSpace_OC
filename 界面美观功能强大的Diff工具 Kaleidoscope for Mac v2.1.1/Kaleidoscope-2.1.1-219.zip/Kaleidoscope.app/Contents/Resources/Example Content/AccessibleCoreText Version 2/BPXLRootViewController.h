//
//  BPXLRootViewController.h
//  AccessibleCoreText
//
//  Created by Doug Russell on 10/10/12.
//
//

#import <UIKit/UIKit.h>

@interface BPXLRootViewController : UIViewController

@end
